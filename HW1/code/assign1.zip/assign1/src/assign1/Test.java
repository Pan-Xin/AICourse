package assign1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Test {

	public static void main(String[] args) throws IOException {
		GP gp = new GP();
		ArrayList<TrainingData> trainData = getTrainData();
		gp.setTrainData(trainData);
		gp.runGP();
	}
	
	public static ArrayList<TrainingData> getTrainData() throws IOException{
		ArrayList<TrainingData> trainData = new ArrayList<>();
		BufferedReader reader = new BufferedReader(new FileReader("training-set.csv"));
		String line = null;
		while((line = reader.readLine()) != null) {
			String[] item = line.split(",");
			ArrayList<Double> list = new ArrayList<>();
			for(String s: item) {
				Double d = Double.parseDouble(s);
				list.add(d);
			}
			TrainingData t = new TrainingData(list);
			trainData.add(t);
		}
		return trainData;
	}

}
