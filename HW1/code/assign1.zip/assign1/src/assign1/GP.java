package assign1;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

// GP Class: implement the GP procedure
public class GP {
	private int initSize; // the size of initial generation
	private double crossoverRate; // the crossover rate
	private double copyRate; // the copy rate
	private double mutateRate; // the mutate rate
	private int maxGeneration; // the max times of evolution
	private int minDifference; // the min error
	private int copyTParam; // pick copyTParam ones from all to join the tournament
	private int crossoverTParam; // pick crossoverTParam ones from all to join the tournament
	private int mutateTParam; // pick mutateTParam ones from all to join the tournament
	
	private ArrayList<TrainingData> trainData; // it is the training data for GP
	
	// the constructor
	GP(int initSize, double crossoverRate, double copyRate, double mutateRate,
			int maxGeneration, int minDifference,
			int copyTParam, int crossoverTParam, int mutateTParam,
			ArrayList<TrainingData> trainData){
		this.initSize = initSize;
		this.crossoverRate = crossoverRate;
		this.copyRate = copyRate;
		this.mutateRate = mutateRate;
		this.maxGeneration = maxGeneration;
		this.minDifference = minDifference;
		this.copyTParam = copyTParam;
		this.crossoverTParam = crossoverTParam;
		this.mutateTParam = mutateTParam;
		this.trainData = trainData;
	}
	
	GP(){
		initSize = 5000;
		crossoverRate = 0.85;
		copyRate = 0.15;
		mutateRate = 0.02;
		maxGeneration = 5000;
		minDifference = 0;
		copyTParam = 3;
		crossoverTParam = 3;
		mutateTParam = 3;
		trainData = new ArrayList<>();
	}
	
	// run the GP procedure
	public void runGP() throws IOException {
		int size = initSize;
		// get the first generation
		ArrayList<Program> generation = initGeneration();
		int times = 0;
		double diff = 0;
		double lastDiff = diff;
		int diffCont = 0;
		Random random = new Random();
		int copyNum = (int)(size * copyRate);
		int crossoverNum = (int)(size * crossoverRate);
		int mutateNum = (int)(size * mutateRate);
		while(times < maxGeneration && diff <= 0.99) {
			ArrayList<Program> newGen = new ArrayList<>(); // represent the new generation
			// do the copy procedure
			int cont = 0;
			while(cont != copyNum) {
				ArrayList<Program> res = runTournament(generation, copyTParam, 1);
				newGen.add(res.get(0));
				cont ++;
			}
			// do the crossover procedure
			cont = 0;
			while(cont != crossoverNum) {
				ArrayList<Program> res = runTournament(generation, crossoverTParam, 2);
				ArrayList<Program> plist = crossoverFunc(res.get(0), res.get(1));
				newGen.addAll(plist);
				cont += 2;
			}
			// do the mutate procedure
			cont = 0;
			while(cont != mutateNum) {
				ArrayList<Program> res = runTournament(generation, mutateTParam, 1);
				Program p = mutationFunc(res.get(0));
				int index = random.nextInt(size);
				newGen.set(index, p);
				cont ++;
			}
			generation = newGen;
			Collections.sort(generation);
			lastDiff = diff;
			diff = fitnessFunc(generation.get(0));
			if(diff == lastDiff) diffCont ++;
			if(diffCont == 100) {
				mutateRate += 0.01;
				diffCont = 0;
			}
			times ++;
			size = generation.size();
			System.out.println("Times:"+times+"   Fitness:"+diff);
			if(diff == minDifference) System.out.println("Reach the Min Difference");
			if(times == maxGeneration) System.out.println("Reach the Max Generation");
		}
		writeResult(generation.get(0));
	}
	
//	// use error-correction to optimize the program
//	private ArrayList<Program> optimizeProgram(ArrayList<Program> newGen) {
//		for(Program p: newGen) {
//			for(TrainingData t: trainData) {
//				ArrayList<Double> d = new ArrayList<>();
//				ArrayList<Double> tData = t.getData();
//				ArrayList<Double> pData = p.getData();
//				int dValue = tData.get(9).intValue();
//				int fValue = getOutput(p, t);
//				for(int i=0; i<9; i++) {
//					double tmp = (dValue - fValue) * tData.get(i) + pData.get(i);
//					d.add(tmp);
//				}
//				double tmp = (dValue - fValue) + pData.get(9);
//				d.add(tmp);
//				p.setData(d);
//			}
//		}
//		return newGen;
//	}
	
	// get the program's output label
	private int getOutput(Program p, TrainingData t) {
		double sum = 0;
		ArrayList<Double> pData = p.getData();
		ArrayList<Double> tData = t.getData();
		for(int i=0; i<9; i++)
			sum += pData.get(i) * tData.get(i);
		if(sum >= pData.get(9)) return 1;
		return 0;
	}

	// write result 
	private void writeResult(Program program) throws IOException {
		File file = new File("result.txt");
		BufferedWriter bw = new BufferedWriter(new FileWriter(file));
		bw.write("******   THE PROGRAM:   ******");
		bw.newLine();
		for(Double d: program.getData()) {
			bw.write(d.toString());
			bw.newLine();
		}
		bw.newLine();
		bw.write("******   THE LABEL:   ******");
		bw.newLine();
		ArrayList<Double> pData = program.getData();
		int cont = 0;
		for(TrainingData t: trainData) {
			ArrayList<Double> data = t.getData();
			double sum = 0;
			for(int i=0; i<9; i++)
				sum += pData.get(i) * data.get(i);
			int pLabel = 0;
			if(sum >= pData.get(9)) pLabel = 1;
			bw.write(String.valueOf(pLabel)+" ");
			cont ++;
			if(cont == 7) {
				bw.newLine();
				cont = 0;
			}
		}
		bw.close();
	}

	// get the initial generation
	public ArrayList<Program> initGeneration(){
		ArrayList<Program> generation = new ArrayList<>();
		Random random = new Random();
		// get a random double number from (-10, 10)
		for(int i=0; i<initSize; i++) {
			ArrayList<Double> tmp = new ArrayList<>(); 
			int isNeg = random.nextInt(10);
			isNeg ++;
			if(Math.random() > 0.5) isNeg *= -1;
			for(int j=0; j<10; j++)
				tmp.add(Math.random()*isNeg); 
			Program p = new Program(tmp);
			p.setFitness(fitnessFunc(p));
			generation.add(p);
		}
		return generation;
	}
	
	// the mutation function
	public Program mutationFunc(Program p) {
		ArrayList<Double> data = p.getData();
		Random random = new Random();
		int totalNum = random.nextInt(10);
		int isNeg = random.nextInt(10);
		isNeg ++;
		if(Math.random() > 0.5) isNeg *= -1;
		// get a random double number from (-10, 10)
		for(int i=0; i<totalNum; i++) {
			int index = random.nextInt(10);
			data.set(index, Math.random()*isNeg);
		}
		p.setData(data);
		return p;
	}
	
	// the crossover function
	public ArrayList<Program> crossoverFunc(Program p1, Program p2) {
		ArrayList<Double> p1Data = p1.getData();
		ArrayList<Double> p2Data = p2.getData();
		Random random = new Random();
		int num = random.nextInt(9);
		num ++;
		ArrayList<Double> data1 = new ArrayList<>();
		ArrayList<Double> data2 = new ArrayList<>();
		// do crossover and produce two children
		for(int i=0; i<num; i++) {
			data1.add(p1Data.get(i));
			data2.add(p2Data.get(i));
		}
		for(int i=num; i<10; i++) {
			data1.add(p2Data.get(i));
			data2.add(p1Data.get(i));
		}
		ArrayList<Program> res = new ArrayList<>();
		Program child1 = new Program(data1);
		Program child2 = new Program(data2);
		res.add(child1);
		res.add(child2);
		return res;
	}
	
	// the fitness function
	public double fitnessFunc(Program p) {
		double res = -1;
		// if function input is empty then break
		if(trainData.size() == 0 || p.getData().size() == 0) return res;
		// calculate the fitness value
		int cont = 0;
		for(TrainingData t: trainData) {
			int pLabel = getOutput(p, t); // get the predicted label
			// accumulate the total differences between predicted labels and actual labels
			cont += Math.abs(pLabel - t.getData().get(9).intValue()); 
		}
		res = 1 - cont*1.0 / trainData.size();
		return res;
	}
	
	// get a random program array then run the tournament algorithm
	public ArrayList<Program> runTournament(ArrayList<Program> generation, int tParam, int n){
		ArrayList<Program> arr = new ArrayList<>();
		Random random = new Random();
		for(int i=0; i<tParam; i++) {
			int tmp = random.nextInt(initSize);
			arr.add(generation.get(tmp));
		}
		ArrayList<Program> pArr = tournamentFunc(arr, n);
		return pArr;
	}
	
	
	// the tournament algorithm (pick the n lowest ones)
	public ArrayList<Program> tournamentFunc(ArrayList<Program> list, int n){
		for(Program p: list) {
			double value = fitnessFunc(p);
			p.setFitness(value);
		}
		Collections.sort(list);
		ArrayList<Program> res = new ArrayList<>();
		for(int i=0; i<n; i++) res.add(list.get(i));
		return res;
	}
	
	// getter and setter
	public int getInitSize() {
		return initSize;
	}

	public void setInitSize(int initSize) {
		this.initSize = initSize;
	}

	public double getCrossoverRate() {
		return crossoverRate;
	}

	public void setCrossoverRate(double crossoverRate) {
		this.crossoverRate = crossoverRate;
	}

	public double getCopyRate() {
		return copyRate;
	}

	public void setCopyRate(double copyRate) {
		this.copyRate = copyRate;
	}

	public double getMutateRate() {
		return mutateRate;
	}

	public void setMutateRate(double mutateRate) {
		this.mutateRate = mutateRate;
	}

	public int getMaxGeneration() {
		return maxGeneration;
	}

	public void setMaxGeneration(int maxGeneration) {
		this.maxGeneration = maxGeneration;
	}

	public int getMinDifference() {
		return minDifference;
	}

	public void setMinDifference(int minDifference) {
		this.minDifference = minDifference;
	}

	public int getCopyTParam() {
		return copyTParam;
	}

	public void setCopyTParam(int copyTParam) {
		this.copyTParam = copyTParam;
	}

	public int getCrossoverTParam() {
		return crossoverTParam;
	}

	public void setCrossoverTParam(int crossoverTParam) {
		this.crossoverTParam = crossoverTParam;
	}

	public int getMutateTParam() {
		return mutateTParam;
	}

	public void setMutateTParam(int mutateTParam) {
		this.mutateTParam = mutateTParam;
	}

	public ArrayList<TrainingData> getTrainData() {
		return trainData;
	}

	public void setTrainData(ArrayList<TrainingData> trainData) {
		this.trainData = trainData;
	}
	
	
}
