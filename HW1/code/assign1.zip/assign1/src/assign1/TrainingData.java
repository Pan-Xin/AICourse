package assign1;

import java.util.ArrayList;

// TrainingData Class: implement it to represent the input tuples
public class TrainingData {
	private ArrayList<Double> data;
	
	// constructor
	TrainingData(ArrayList<Double> data){
		this.data = data;
	}
	
	TrainingData(){}
	
	// setter and getter 
	public ArrayList<Double> getData() {
		return data;
	}

	public void setData(ArrayList<Double> data) {
		this.data = data;
	}
}
