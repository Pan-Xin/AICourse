package assign1;

import java.util.ArrayList;

// Program Class: implement it to represent program tuples
public class Program implements Comparable<Program> {
	private ArrayList<Double> data;
	
	private double fitness; // it is the fitness value
	
	// constructor
	Program(ArrayList<Double> data){
		this.data = data;
	}
	
	Program(){}
	
	// setter and getter
	public ArrayList<Double> getData() {
		return data;
	}

	public void setData(ArrayList<Double> data) {
		this.data = data;
	}

	public double getFitness() {
		return fitness;
	}

	public void setFitness(double fitness) {
		this.fitness = fitness;
	}

	@Override
	public int compareTo(Program o) {
		return Double.compare(o.getFitness(), this.fitness);
	}
	
}
